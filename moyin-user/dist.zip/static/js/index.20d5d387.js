import{_ as e,e as c,f as o}from"./index.feaf31e6.js";const r={};function n(t,s){return c(),o("div")}const a=e(r,[["render",n]]);export{a as default};
